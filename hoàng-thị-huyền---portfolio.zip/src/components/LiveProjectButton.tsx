import React from 'react';
import { ExternalLink } from 'lucide-react';
import { Theme } from '../types';

interface LiveProjectButtonProps {
  label?: string;
  onClick?: () => void;
  href?: string;
  theme?: Theme;
  className?: string;
}

export const LiveProjectButton: React.FC<LiveProjectButtonProps> = ({
  label = 'Live Project',
  onClick,
  href,
  theme = 'dark',
  className = '',
}) => {
  const isDark = theme === 'dark';

  const content = (
    <span className="flex items-center gap-2">
      <span>{label}</span>
      <ExternalLink size={14} className="opacity-75 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
    </span>
  );

  const buttonClasses = `group inline-flex items-center justify-center rounded-full border-2 font-medium uppercase tracking-widest cursor-pointer transition-all duration-300 px-8 py-3 sm:px-10 sm:py-3.5 text-sm sm:text-base whitespace-nowrap ${
    isDark
      ? 'border-[#D7E2EA] text-[#D7E2EA] hover:bg-[#D7E2EA]/10 hover:border-white'
      : 'border-slate-800 text-slate-800 hover:bg-slate-800/10'
  } ${className}`;

  if (href) {
    return (
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        onClick={onClick}
        className={buttonClasses}
      >
        {content}
      </a>
    );
  }

  return (
    <button onClick={onClick} className={buttonClasses}>
      {content}
    </button>
  );
};
