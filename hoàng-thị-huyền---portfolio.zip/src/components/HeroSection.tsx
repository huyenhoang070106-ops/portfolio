import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Navbar } from './Navbar';
import { ContactButton } from './ContactButton';
import { Magnet } from './Magnet';
import { Language, Theme } from '../types';
import { PERSONAL_INFO, PDF_PHOTOS, TRANSLATIONS } from '../data/translations';

interface HeroSectionProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  theme: Theme;
  onThemeToggle: () => void;
  onOpenContact: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  language,
  onLanguageChange,
  theme,
  onThemeToggle,
  onOpenContact,
}) => {
  const [imgSrc, setImgSrc] = useState<string>(PDF_PHOTOS.portrait1);
  const isDark = theme === 'dark';
  const t = TRANSLATIONS[language];

  // Fallback image handler in case of network constraint
  const handleImageError = () => {
    if (imgSrc !== PDF_PHOTOS.drivePortrait1) {
      setImgSrc(PDF_PHOTOS.drivePortrait1);
    } else if (imgSrc !== PDF_PHOTOS.portraitGec) {
      setImgSrc(PDF_PHOTOS.portraitGec);
    }
  };

  return (
    <section className="relative w-full h-screen min-h-[640px] max-h-[1100px] flex flex-col justify-between overflow-x-clip select-none">
      {/* Top Navbar */}
      <Navbar
        language={language}
        onLanguageChange={onLanguageChange}
        theme={theme}
        onThemeToggle={onThemeToggle}
        onOpenContact={onOpenContact}
      />

      {/* Massive Hero Heading */}
      <div className="w-full overflow-hidden text-center mt-6 sm:mt-4 md:-mt-5 z-0 pointer-events-none">
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.15, ease: [0.25, 0.1, 0.25, 1] }}
          className={`font-black uppercase tracking-tight leading-none whitespace-nowrap w-full ${
            isDark ? 'hero-heading' : 'hero-heading-light'
          } text-[14vw] sm:text-[15vw] md:text-[16vw] lg:text-[17.5vw]`}
        >
          {language === 'vi' ? (
            <>Hi, i&apos;m huyen</>
          ) : (
            <>Hi, i&apos;m huyen</>
          )}
        </motion.h1>
      </div>

      {/* Hero Magnetic Portrait */}
      <div className="absolute left-1/2 -translate-x-1/2 z-10 w-[280px] sm:w-[360px] md:w-[440px] lg:w-[520px] top-1/2 -translate-y-1/2 sm:top-auto sm:translate-y-0 sm:bottom-0 pointer-events-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.6, ease: [0.25, 0.1, 0.25, 1] }}
        >
          <Magnet
            padding={150}
            strength={3}
            activeTransition="transform 0.3s ease-out"
            inactiveTransition="transform 0.6s ease-in-out"
            className="w-full flex items-center justify-center cursor-grab active:cursor-grabbing"
          >
            <div className="relative group">
              {/* Subtle ambient aura glow behind portrait */}
              <div
                className="absolute inset-0 -m-4 rounded-full blur-3xl opacity-40 transition-opacity duration-500 group-hover:opacity-60"
                style={{
                  background: 'radial-gradient(circle, #B600A8 0%, #7621B0 50%, transparent 70%)',
                }}
              />
              <div className="relative z-10 rounded-[32px] sm:rounded-[44px] overflow-hidden border-2 border-white/20 shadow-[0_25px_60px_rgba(0,0,0,0.7)] aspect-[3/4] max-h-[56vh] sm:max-h-[66vh] md:max-h-[72vh] mx-auto bg-zinc-900">
                <img
                  src={imgSrc}
                  alt={PERSONAL_INFO.fullName}
                  onError={handleImageError}
                  referrerPolicy="no-referrer"
                  loading="eager"
                  className="w-full h-full object-cover select-none pointer-events-none transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-black/80 via-black/30 to-transparent pointer-events-none flex items-end justify-center pb-4">
                  <span className="text-xs uppercase tracking-widest font-semibold text-white/90 px-3 py-1 rounded-full bg-black/40 backdrop-blur-md border border-white/10">
                    {PERSONAL_INFO.fullName}
                  </span>
                </div>
              </div>
            </div>
          </Magnet>
        </motion.div>
      </div>

      {/* Bottom Bar: Right Contact button */}
      <div className="w-full px-6 md:px-10 pb-7 sm:pb-8 md:pb-10 flex items-end justify-end z-20 relative">
        {/* Right Contact button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
          className="shrink-0"
        >
          <ContactButton
            label={t.hero.ctaContact}
            onClick={onOpenContact}
          />
        </motion.div>
      </div>
    </section>
  );
};
