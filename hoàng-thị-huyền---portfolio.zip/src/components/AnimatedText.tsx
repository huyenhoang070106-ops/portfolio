import React, { useRef } from 'react';
import { motion, useScroll, useTransform, MotionValue } from 'framer-motion';

interface AnimatedTextProps {
  text: string;
  className?: string;
  theme?: 'dark' | 'light';
}

interface CharacterProps {
  char: string;
  progress: MotionValue<number>;
  range: [number, number];
}

const Character: React.FC<CharacterProps> = ({ char, progress, range }) => {
  const opacity = useTransform(progress, range, [0.22, 1]);

  return (
    <span className="relative inline-block">
      <span className="opacity-20 select-none">{char}</span>
      <motion.span
        style={{ opacity }}
        className="absolute left-0 top-0 select-text"
      >
        {char}
      </motion.span>
    </span>
  );
};

export const AnimatedText: React.FC<AnimatedTextProps> = ({
  text,
  className = '',
  theme = 'dark',
}) => {
  const containerRef = useRef<HTMLParagraphElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start 0.85', 'end 0.25'],
  });

  const words = text.split(' ');
  const totalChars = text.length;
  let charCounter = 0;

  return (
    <p
      ref={containerRef}
      className={`relative font-normal leading-[1.85] max-w-[680px] mx-auto text-justify [text-align-last:center] [hyphens:none] [word-break:keep-all] ${
        theme === 'dark' ? 'text-[#D7E2EA]' : 'text-slate-700'
      } ${className}`}
      style={{
        fontSize: 'clamp(1.05rem, 1.8vw, 1.35rem)',
      }}
    >
      {words.map((word, wIdx) => {
        const wordChars = word.split('');
        const wordElements = (
          <span key={wIdx} className="inline-block whitespace-nowrap mr-[0.3em]">
            {wordChars.map((char, cIdx) => {
              const currentIndex = charCounter;
              charCounter++;
              const start = currentIndex / totalChars;
              const end = (currentIndex + 1) / totalChars;
              return (
                <Character
                  key={cIdx}
                  char={char}
                  progress={scrollYProgress}
                  range={[start, end]}
                />
              );
            })}
          </span>
        );
        // Count the space character for timing progression
        charCounter++;
        return wordElements;
      })}
    </p>
  );
};
