import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sun, Moon, Globe, Menu, X } from 'lucide-react';
import { Language, Theme } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface NavbarProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  theme: Theme;
  onThemeToggle: () => void;
  onOpenContact: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  onLanguageChange,
  theme,
  onThemeToggle,
  onOpenContact,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = TRANSLATIONS[language];
  const isDark = theme === 'dark';

  const navLinks = [
    { label: t.nav.about, href: '#about' },
    { label: t.nav.education, href: '#education' },
    { label: t.nav.skills, href: '#skills' },
    { label: t.nav.experience, href: '#experience' },
    { label: t.nav.projects, href: '#projects' },
  ];

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: [0.25, 0.1, 0.25, 1], delay: 0 }}
      className="w-full px-6 md:px-10 pt-6 md:pt-8 relative z-40 select-none"
    >
      <div className="flex items-center justify-between w-full">
        {/* Brand / Logo */}
        <a
          href="#"
          className={`font-black uppercase tracking-tight text-lg md:text-xl lg:text-2xl transition-opacity hover:opacity-80 ${
            isDark ? 'text-[#D7E2EA]' : 'text-slate-900'
          }`}
        >
          Huyen<span className="text-[#B600A8]">.</span>Hoang
        </a>

        {/* Desktop Nav Links */}
        <nav className="hidden lg:flex items-center gap-8 xl:gap-12">
          {navLinks.map((link, index) => (
            <a
              key={index}
              href={link.href}
              className={`font-medium uppercase tracking-wider text-sm md:text-base xl:text-[1.15rem] transition-opacity duration-200 hover:opacity-70 ${
                isDark ? 'text-[#D7E2EA]' : 'text-slate-800'
              }`}
            >
              {link.label}
            </a>
          ))}
          <button
            onClick={onOpenContact}
            className={`font-medium uppercase tracking-wider text-sm md:text-base xl:text-[1.15rem] transition-opacity duration-200 hover:opacity-70 cursor-pointer ${
              isDark ? 'text-[#D7E2EA]' : 'text-slate-800'
            }`}
          >
            {t.nav.contact}
          </button>
        </nav>

        {/* Action Controls: Language Switcher, Dark/Light Mode, Mobile Menu */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Language Toggle */}
          <div
            className={`flex items-center rounded-full p-1 border text-xs font-semibold uppercase tracking-wider transition-colors ${
              isDark ? 'bg-[#18181b]/80 border-zinc-800 text-zinc-300' : 'bg-slate-100 border-slate-200 text-slate-700'
            }`}
          >
            <button
              onClick={() => onLanguageChange('vi')}
              className={`px-2.5 py-1 rounded-full transition-all cursor-pointer ${
                language === 'vi'
                  ? 'bg-gradient-to-r from-[#B600A8] to-[#7621B0] text-white shadow-sm font-bold'
                  : 'hover:opacity-70'
              }`}
              title="Chuyển sang Tiếng Việt"
            >
              VI
            </button>
            <button
              onClick={() => onLanguageChange('en')}
              className={`px-2.5 py-1 rounded-full transition-all cursor-pointer ${
                language === 'en'
                  ? 'bg-gradient-to-r from-[#B600A8] to-[#7621B0] text-white shadow-sm font-bold'
                  : 'hover:opacity-70'
              }`}
              title="Switch to English"
            >
              EN
            </button>
          </div>

          {/* Theme Toggle Button */}
          <button
            onClick={onThemeToggle}
            className={`p-2 rounded-full border transition-all cursor-pointer ${
              isDark
                ? 'bg-[#18181b]/80 border-zinc-800 text-amber-400 hover:bg-zinc-800'
                : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
            }`}
            title={isDark ? (language === 'vi' ? 'Chuyển giao diện sáng' : 'Switch to Light Mode') : (language === 'vi' ? 'Chuyển giao diện tối' : 'Switch to Dark Mode')}
            aria-label="Toggle theme"
          >
            {isDark ? <Sun size={17} /> : <Moon size={17} />}
          </button>

          {/* Mobile Menu Hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`lg:hidden p-2 rounded-full border transition-colors cursor-pointer ${
              isDark ? 'bg-[#18181b]/80 border-zinc-800 text-[#D7E2EA]' : 'bg-slate-100 border-slate-200 text-slate-800'
            }`}
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className={`lg:hidden mt-4 rounded-2xl border p-5 backdrop-blur-xl ${
              isDark ? 'bg-[#141416]/95 border-zinc-800 text-[#D7E2EA]' : 'bg-white/95 border-slate-200 text-slate-900 shadow-xl'
            }`}
          >
            <div className="flex flex-col space-y-4">
              {navLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="font-semibold uppercase tracking-wider text-base hover:text-[#B600A8] transition-colors py-1"
                >
                  {link.label}
                </a>
              ))}
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenContact();
                }}
                className="text-left font-semibold uppercase tracking-wider text-base text-[#B600A8] py-1 cursor-pointer"
              >
                {t.nav.contact}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
};
