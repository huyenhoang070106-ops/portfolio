import React from 'react';
import { ContactButton } from './ContactButton';
import { PERSONAL_INFO, TRANSLATIONS } from '../data/translations';
import { Language, Theme } from '../types';
import { Mail, Phone, MapPin, Linkedin, Facebook, ArrowUp } from 'lucide-react';

interface FooterProps {
  language: Language;
  theme: Theme;
  onOpenContact: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  language,
  theme,
  onOpenContact,
}) => {
  const t = TRANSLATIONS[language];
  const isDark = theme === 'dark';

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer
      id="contact"
      className={`w-full px-6 md:px-12 py-16 sm:py-20 border-t relative z-30 transition-colors duration-300 ${
        isDark ? 'bg-[#0C0C0C] border-zinc-800 text-[#D7E2EA]' : 'bg-slate-900 border-slate-800 text-slate-200'
      }`}
    >
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-10">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#B600A8] font-bold">
            {t.contact.badge}
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black uppercase tracking-tight mt-2 text-white">
            {language === 'vi' ? 'Kiến tạo tương lai cùng nhau' : "Let's build something remarkable"}
          </h2>
          <p className="text-sm text-zinc-400 mt-2 max-w-md">
            {language === 'vi'
              ? 'Sinh viên Kinh tế Quốc tế K63 - ĐH Ngoại thương. Đam mê phân tích dữ liệu và quản trị dự án chất lượng cao.'
              : 'Intake 63 International Economics - Foreign Trade University. Dedicated to high-stakes project management and data analytics.'}
          </p>

          <div className="flex flex-wrap items-center gap-4 mt-6 text-sm">
            <a
              href={`mailto:${PERSONAL_INFO.email}`}
              className="flex items-center gap-2 hover:text-[#B600A8] transition-colors"
            >
              <Mail size={16} />
              <span>{PERSONAL_INFO.email}</span>
            </a>
            <span className="opacity-40">·</span>
            <a
              href={`tel:${PERSONAL_INFO.phone.replace(/[^0-9+]/g, '')}`}
              className="flex items-center gap-2 hover:text-[#B600A8] transition-colors"
            >
              <Phone size={16} />
              <span>{PERSONAL_INFO.phone}</span>
            </a>
            <span className="opacity-40">·</span>
            <span className="flex items-center gap-2 text-zinc-400">
              <MapPin size={16} />
              <span>{PERSONAL_INFO.location}</span>
            </span>
          </div>
        </div>

        <div className="flex flex-col items-start md:items-end gap-5">
          <ContactButton
            label={t.contact.buttonText}
            onClick={onOpenContact}
          />

          <div className="flex items-center gap-4">
            <a
              href={PERSONAL_INFO.linkedIn}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-full bg-zinc-800/80 text-zinc-300 hover:text-white hover:bg-zinc-700 transition-colors"
              aria-label="LinkedIn profile"
            >
              <Linkedin size={18} />
            </a>
            <a
              href={PERSONAL_INFO.facebookZalo}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-full bg-zinc-800/80 text-zinc-300 hover:text-white hover:bg-zinc-700 transition-colors"
              aria-label="Facebook / Zalo profile"
            >
              <Facebook size={18} />
            </a>
            <button
              onClick={scrollToTop}
              className="p-3 rounded-full bg-zinc-800/80 text-zinc-300 hover:text-white hover:bg-zinc-700 transition-colors"
              aria-label="Scroll to top"
              title="Lên đầu trang"
            >
              <ArrowUp size={18} />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto mt-12 pt-6 border-t border-zinc-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-zinc-500 gap-4">
        <div>
          © {new Date().getFullYear()} {PERSONAL_INFO.fullName} (Huyen Hoang). All rights reserved.
        </div>
        <div className="flex items-center gap-4">
          <span>Foreign Trade University</span>
          <span>·</span>
          <span>Global Economics Club</span>
          <span>·</span>
          <span>G&apos;CONTEST 2026</span>
        </div>
      </div>
    </footer>
  );
};
