import React, { useRef, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { LiveProjectButton } from './LiveProjectButton';
import { FadeIn } from './FadeIn';
import { ProjectCardData, Language, Theme } from '../types';
import { TRANSLATIONS } from '../data/translations';
import { ExternalLink, X, Eye } from 'lucide-react';

interface ProjectsSectionProps {
  language: Language;
  theme: Theme;
}

interface ProjectCardProps {
  project: ProjectCardData;
  index: number;
  totalCards: number;
  theme: Theme;
  language: Language;
  onPreviewImage: (src: string, title: string) => void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({
  project,
  index,
  totalCards,
  theme,
  language,
  onPreviewImage,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'start start'],
  });

  // Scale down calculation as specified in the brief:
  // targetScale = 1 - (totalCards - 1 - index) * 0.03
  const targetScale = 1 - (totalCards - 1 - index) * 0.03;
  const scale = useTransform(scrollYProgress, [0, 1], [1, targetScale]);

  const isDark = theme === 'dark';

  return (
    <div
      ref={containerRef}
      className="h-[85vh] min-h-[640px] sticky top-24 md:top-32 flex items-center justify-center select-none"
    >
      <motion.div
        style={{
          scale,
          top: `${index * 28}px`,
        }}
        className={`w-full max-w-6xl rounded-[40px] sm:rounded-[50px] md:rounded-[60px] border-2 p-4 sm:p-6 md:p-8 shadow-2xl relative transition-colors duration-300 ${
          isDark
            ? 'bg-[#0C0C0C] border-[#D7E2EA] text-[#D7E2EA]'
            : 'bg-white border-slate-300 text-slate-800 shadow-xl'
        }`}
      >
        {/* Top Row: Number, category label, project name, and Live Project button */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-[#D7E2EA]/20">
          <div className="flex items-center gap-4 sm:gap-6">
            {/* Huge Number */}
            <span
              className={`font-black leading-none ${isDark ? 'text-[#D7E2EA]' : 'text-slate-900'}`}
              style={{ fontSize: 'clamp(2.5rem, 6vw, 90px)' }}
            >
              {project.number}
            </span>

            <div>
              <div className="flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#B600A8]">
                <span>{project.category}</span>
                <span>·</span>
                <span>{project.period}</span>
              </div>
              <h3 className="text-xl sm:text-2xl md:text-3xl font-black uppercase tracking-tight">
                {project.title}
              </h3>
              <p className="text-xs sm:text-sm font-medium opacity-80 text-[#BBCCD7]">
                {project.role}
              </p>
            </div>
          </div>

          {/* Ghost Live Project Button */}
          <div className="shrink-0 flex items-center gap-3">
            <LiveProjectButton
              label={language === 'vi' ? 'Xem chi tiết' : 'Live Project'}
              href={project.liveLink}
              theme={theme}
            />
          </div>
        </div>

        {/* Project Description & Metrics */}
        <div className="my-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs sm:text-sm opacity-90">
          <p className="max-w-2xl line-clamp-2 sm:line-clamp-2">
            {project.description}
          </p>
          <div className="flex flex-wrap items-center gap-1.5 shrink-0">
            {project.tags.map((tag, tIdx) => (
              <span
                key={tIdx}
                className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-[#B600A8]/20 text-[#D7E2EA] border border-[#B600A8]/30"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Bottom Row: Two-column image grid (Left 40% with 2 stacked images, Right 60% with 1 tall image) */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 sm:gap-4 mt-2">
          {/* Left Column (40% width on md+ -> 5 of 12 cols): 2 stacked images */}
          <div className="md:col-span-5 flex flex-col gap-3 sm:gap-4">
            {/* Left Top Image */}
            <div
              onClick={() => onPreviewImage(project.col1Image1, `${project.title} - Visual 1`)}
              className="relative group cursor-pointer overflow-hidden rounded-[40px] sm:rounded-[50px] md:rounded-[60px] border border-white/10"
              style={{ height: 'clamp(130px, 16vw, 230px)' }}
            >
              <img
                src={project.col1Image1}
                alt={`${project.title} Preview 1`}
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="p-2 rounded-full bg-white/20 backdrop-blur-md text-white">
                  <Eye size={18} />
                </span>
              </div>
            </div>

            {/* Left Bottom Image */}
            <div
              onClick={() => onPreviewImage(project.col1Image2, `${project.title} - Visual 2`)}
              className="relative group cursor-pointer overflow-hidden rounded-[40px] sm:rounded-[50px] md:rounded-[60px] border border-white/10"
              style={{ height: 'clamp(160px, 22vw, 340px)' }}
            >
              <img
                src={project.col1Image2}
                alt={`${project.title} Preview 2`}
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="p-2 rounded-full bg-white/20 backdrop-blur-md text-white">
                  <Eye size={18} />
                </span>
              </div>
            </div>
          </div>

          {/* Right Column (60% width on md+ -> 7 of 12 cols): 1 tall image */}
          <div className="md:col-span-7">
            <div
              onClick={() => onPreviewImage(project.col2Image, `${project.title} - Main Visual`)}
              className="relative group cursor-pointer overflow-hidden rounded-[40px] sm:rounded-[50px] md:rounded-[60px] border border-white/10 w-full h-[300px] sm:h-[400px] md:h-full min-h-[300px]"
            >
              <img
                src={project.col2Image}
                alt={`${project.title} Main Preview`}
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="p-2 rounded-full bg-white/20 backdrop-blur-md text-white">
                  <Eye size={22} />
                </span>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export const ProjectsSection: React.FC<ProjectsSectionProps> = ({
  language,
  theme,
}) => {
  const [activePreview, setActivePreview] = useState<{ src: string; title: string } | null>(null);
  const t = TRANSLATIONS[language];
  const isDark = theme === 'dark';
  const totalCards = t.projects.items.length;

  return (
    <section
      id="projects"
      className={`relative w-full rounded-t-[40px] sm:rounded-t-[50px] md:rounded-t-[60px] -mt-10 sm:-mt-12 md:-mt-14 z-20 px-4 sm:px-6 md:px-10 pt-20 pb-32 transition-colors duration-300 ${
        isDark ? 'bg-[#0C0C0C]' : 'bg-[#0C0C0C]'
      }`}
    >
      <div className="max-w-6xl mx-auto">
        {/* Section Heading: "Project" singular with .hero-heading gradient */}
        <FadeIn delay={0} y={40}>
          <div className="text-center mb-16 sm:mb-20">
            <span className="text-xs uppercase tracking-widest text-[#B600A8] font-bold">
              {t.projects.badge}
            </span>
            <h2
              className="font-black uppercase leading-none tracking-tight hero-heading mt-1"
              style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
            >
              {t.projects.heading}
            </h2>
            <p className="mt-3 text-xs sm:text-sm font-semibold uppercase tracking-widest text-[#BBCCD7]">
              {t.projects.subtitle}
            </p>
          </div>
        </FadeIn>

        {/* 3 Sticky-Stacking Project Cards */}
        <div className="flex flex-col space-y-12 sm:space-y-20 pb-20">
          {t.projects.items.map((project, idx) => (
            <ProjectCard
              key={project.id}
              project={project}
              index={idx}
              totalCards={totalCards}
              theme={theme}
              language={language}
              onPreviewImage={(src, title) => setActivePreview({ src, title })}
            />
          ))}
        </div>
      </div>

      {/* Lightbox Image Preview Modal */}
      {activePreview && (
        <div
          onClick={() => setActivePreview(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-5xl max-h-[90vh] rounded-3xl overflow-hidden shadow-2xl border border-white/20 bg-zinc-950 cursor-default"
          >
            <button
              onClick={() => setActivePreview(null)}
              className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-black/60 text-white hover:bg-black/90 transition-colors"
              aria-label="Close image preview"
            >
              <X size={20} />
            </button>
            <img
              src={activePreview.src}
              alt={activePreview.title}
              className="max-h-[80vh] w-auto object-contain mx-auto"
            />
            <div className="p-4 bg-zinc-900 text-white text-sm font-medium text-center">
              {activePreview.title}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
