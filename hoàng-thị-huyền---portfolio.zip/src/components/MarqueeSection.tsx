import React, { useRef, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PDF_PHOTOS } from '../data/translations';
import { Language, Theme } from '../types';
import { Eye, X, Award, ExternalLink, Sparkles } from 'lucide-react';

interface MarqueeSectionProps {
  theme: Theme;
  language?: Language;
}

interface MilestoneTile {
  src: string;
  titleVi: string;
  titleEn: string;
  categoryVi: string;
  categoryEn: string;
  descVi: string;
  descEn: string;
}

const MILESTONES: MilestoneTile[] = [
  {
    src: PDF_PHOTOS.gcon26,
    titleVi: "The Final Night · G'CONTEST 2026",
    titleEn: "The Final Night · G'CONTEST 2026",
    categoryVi: "Cuộc thi Toàn quốc",
    categoryEn: "National Competition",
    descVi: "Cuộc thi học thuật đầu tiên về Data Analytics tại Đại học Ngoại thương quy mô hơn 400 thí sinh toàn quốc.",
    descEn: "The premier Data Analytics academic competition at Foreign Trade University with over 400 nationwide contestants.",
  },
  {
    src: PDF_PHOTOS.scholarship,
    titleVi: "Học bổng DB Global Dream Leader Mùa 2",
    titleEn: "DB Global Dream Leader Scholarship Season 2",
    categoryVi: "Học bổng Doanh nghiệp",
    categoryEn: "Corporate Scholarship",
    descVi: "1 trong 25 sinh viên ưu tú toàn quốc được trao tặng học bổng từ Quỹ văn hóa DB Kim Jun Ki.",
    descEn: "Selected among the top 25 outstanding university scholars nationwide by the DB Kim Jun Ki Cultural Foundation.",
  },
  {
    src: PDF_PHOTOS.gtalk25,
    titleVi: "Hội thảo G'TALK 2025",
    titleEn: "G'TALK 2025 Symposium",
    categoryVi: "Sự kiện Học thuật",
    categoryEn: "Academic Symposium",
    descVi: "Chuỗi hội thảo kinh tế chuyên sâu quy tụ dàn diễn giả uy tín và chuyên gia kinh tế đầu ngành.",
    descEn: "In-depth economic symposium series bringing together prominent keynote speakers and industry executives.",
  },
  {
    src: PDF_PHOTOS.db1,
    titleVi: "Tình nguyện viên Dream Leader",
    titleEn: "Dream Leader Volunteer Community Work",
    categoryVi: "Tác động Cộng đồng",
    categoryEn: "Community Impact",
    descVi: "Trực tiếp thiết kế bài giảng, sơn tranh tường và giảng dạy kỹ năng an toàn học đường cho học sinh THCS.",
    descEn: "Designing curricula, painting campus murals, and delivering safety life skill workshops for middle school students.",
  },
  {
    src: PDF_PHOTOS.portraitGec,
    titleVi: "Trưởng Ban Tổ chức · CLB Kinh tế Toàn cầu GEC",
    titleEn: "Head of Organizers · Global Economics Club",
    categoryVi: "Lãnh đạo Sinh viên",
    categoryEn: "Student Leadership",
    descVi: "Điều phối và quản lý toàn bộ bộ máy CLB trực thuộc Khoa Kinh tế Quốc tế - FTU với hơn 100 thành viên.",
    descEn: "Leading all strategic operations and activities of GEC club under the Faculty of International Economics - FTU.",
  },
  {
    src: PDF_PHOTOS.db2,
    titleVi: "Chứng nhận Học bổng Quỹ DB Kim Jun Ki",
    titleEn: "Official DB Scholarship Certificate",
    categoryVi: "Thành tích Nổi bật",
    categoryEn: "Honors & Distinctions",
    descVi: "Giấy chứng nhận chính thức vinh danh tinh thần cống hiến và năng lực lãnh đạo trẻ của Hoàng Thị Huyền.",
    descEn: "Official commendation certificate honoring dedication, character, and exemplary volunteer leadership.",
  },
  {
    src: PDF_PHOTOS.gtalk,
    titleVi: "Hội thảo G'TALK 2026",
    titleEn: "G'TALK 2026 Symposium",
    categoryVi: "Vận hành Sự kiện",
    categoryEn: "Event Execution",
    descVi: "Chỉ đạo sân khấu (Onstage Running) và điều phối trải nghiệm diễn giả cho sự kiện hội trường lớn.",
    descEn: "Onstage floor directing and coordinating keynote speaker experiences for auditorium production.",
  },
  {
    src: PDF_PHOTOS.aiesec,
    titleVi: "Đại sứ Truyền thông Kết nối · AIESEC",
    titleEn: "Media Ambassador · AIESEC Vietnam",
    categoryVi: "Truyền thông Xã hội",
    categoryEn: "Media & Outreach",
    descVi: "Đại sứ chiến dịch Tuyển thành viên Mùa Thu 2026, tư vấn và lan tỏa giá trị lãnh đạo tới sinh viên.",
    descEn: "Official ambassador for Fall 2026 recruitment campaign, mentoring prospective student leaders.",
  },
  {
    src: PDF_PHOTOS.gcontest,
    titleVi: "G'CONTEST 2026 · Data Analytics Contest",
    titleEn: "G'CONTEST 2026 · Master Economist",
    categoryVi: "Quản trị Dự án",
    categoryEn: "Project Management",
    descVi: "Hoạch định chiến lược tổng thể, lập bài toán ngân sách và trực tiếp đàm phán tài trợ doanh nghiệp.",
    descEn: "Formulating master strategic roadmap, managing operational budget, and pitching enterprise sponsors.",
  },
  {
    src: PDF_PHOTOS.portrait1,
    titleVi: "Hoàng Thị Huyền · K63 FTU",
    titleEn: "Hoang Thi Huyen · Intake 63 FTU",
    categoryVi: "Hồ sơ Học tập",
    categoryEn: "Academic Profile",
    descVi: "Học bổng khuyến khích học tập loại A, Giải Nhì HSG Tỉnh môn Tiếng Anh, GPA tốt nghiệp 9.0+.",
    descEn: "Grade A Academic Encouragement Scholarship, Provincial 2nd Prize in English, High School GPA 9.0+.",
  },
];

export const MarqueeSection: React.FC<MarqueeSectionProps> = ({ theme, language = 'vi' }) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [scrollOffset, setScrollOffset] = useState(0);
  const [selectedMilestone, setSelectedMilestone] = useState<MilestoneTile | null>(null);
  const isDark = theme === 'dark';

  // Row 1: First 5 items, tripled for infinite smooth scroll
  const row1Items = [...MILESTONES.slice(0, 5), ...MILESTONES.slice(0, 5), ...MILESTONES.slice(0, 5)];
  // Row 2: Remaining 5 items, tripled
  const row2Items = [...MILESTONES.slice(5), ...MILESTONES.slice(5), ...MILESTONES.slice(5)];

  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current) return;
      const rect = sectionRef.current.getBoundingClientRect();
      const sectionTop = window.scrollY + rect.top;
      // Scroll offset formula: (window.scrollY - sectionTop + window.innerHeight) * 0.3
      const offset = (window.scrollY - sectionTop + window.innerHeight) * 0.3;
      setScrollOffset(offset);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const row1Transform = `translateX(${scrollOffset - 200}px)`;
  const row2Transform = `translateX(${-(scrollOffset - 200)}px)`;

  return (
    <section
      ref={sectionRef}
      className={`w-full overflow-hidden select-none pt-20 sm:pt-28 md:pt-32 pb-14 transition-colors duration-300 relative ${
        isDark ? 'bg-[#0C0C0C]' : 'bg-slate-50'
      }`}
    >
      <div className="flex flex-col gap-4">
        {/* Row 1: Moves RIGHT on scroll */}
        <div
          style={{
            transform: row1Transform,
            willChange: 'transform',
          }}
          className="flex gap-4 transition-transform duration-75 ease-out"
        >
          {row1Items.map((item, idx) => (
            <div
              key={`row1-${idx}`}
              onClick={() => setSelectedMilestone(item)}
              className={`group shrink-0 w-[300px] sm:w-[380px] md:w-[440px] h-[200px] sm:h-[240px] md:h-[280px] rounded-3xl overflow-hidden shadow-xl border cursor-pointer relative transition-all duration-300 hover:scale-[1.03] hover:border-[#B600A8] ${
                isDark ? 'border-zinc-800 bg-zinc-900/60' : 'border-slate-200 bg-white'
              }`}
            >
              <img
                src={item.src}
                alt={language === 'vi' ? item.titleVi : item.titleEn}
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              {/* Overlay with details */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent p-5 flex flex-col justify-end text-white">
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-[#BBCCD7] mb-1">
                  {language === 'vi' ? item.categoryVi : item.categoryEn}
                </span>
                <h4 className="text-sm sm:text-base md:text-lg font-black tracking-tight leading-snug line-clamp-1 group-hover:text-[#B600A8] transition-colors">
                  {language === 'vi' ? item.titleVi : item.titleEn}
                </h4>
                <div className="flex items-center gap-1.5 mt-2 opacity-0 group-hover:opacity-100 transition-opacity text-xs text-white/80 font-medium">
                  <Eye size={13} />
                  <span>{language === 'vi' ? 'Nhấp để xem chi tiết' : 'Click to view'}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Row 2: Moves LEFT on scroll */}
        <div
          style={{
            transform: row2Transform,
            willChange: 'transform',
          }}
          className="flex gap-4 transition-transform duration-75 ease-out"
        >
          {row2Items.map((item, idx) => (
            <div
              key={`row2-${idx}`}
              onClick={() => setSelectedMilestone(item)}
              className={`group shrink-0 w-[300px] sm:w-[380px] md:w-[440px] h-[200px] sm:h-[240px] md:h-[280px] rounded-3xl overflow-hidden shadow-xl border cursor-pointer relative transition-all duration-300 hover:scale-[1.03] hover:border-[#7621B0] ${
                isDark ? 'border-zinc-800 bg-zinc-900/60' : 'border-slate-200 bg-white'
              }`}
            >
              <img
                src={item.src}
                alt={language === 'vi' ? item.titleVi : item.titleEn}
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              {/* Overlay with details */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent p-5 flex flex-col justify-end text-white">
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-[#BBCCD7] mb-1">
                  {language === 'vi' ? item.categoryVi : item.categoryEn}
                </span>
                <h4 className="text-sm sm:text-base md:text-lg font-black tracking-tight leading-snug line-clamp-1 group-hover:text-[#7621B0] transition-colors">
                  {language === 'vi' ? item.titleVi : item.titleEn}
                </h4>
                <div className="flex items-center gap-1.5 mt-2 opacity-0 group-hover:opacity-100 transition-opacity text-xs text-white/80 font-medium">
                  <Eye size={13} />
                  <span>{language === 'vi' ? 'Nhấp để xem chi tiết' : 'Click to view'}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Click Lightbox Modal */}
      <AnimatePresence>
        {selectedMilestone && (
          <div
            onClick={() => setSelectedMilestone(null)}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 cursor-pointer"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-3xl w-full max-h-[90vh] rounded-[36px] overflow-hidden shadow-2xl border border-white/20 bg-zinc-950 text-white cursor-default flex flex-col"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedMilestone(null)}
                className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-black/70 text-white hover:bg-black/95 transition-colors cursor-pointer border border-white/10"
                aria-label="Close"
              >
                <X size={20} />
              </button>

              {/* Image Preview Container */}
              <div className="relative w-full max-h-[58vh] bg-black flex items-center justify-center overflow-hidden">
                <img
                  src={selectedMilestone.src}
                  alt={language === 'vi' ? selectedMilestone.titleVi : selectedMilestone.titleEn}
                  className="max-h-[56vh] w-auto max-w-full object-contain"
                />
              </div>

              {/* Information Panel */}
              <div className="p-6 sm:p-8 bg-zinc-900/95 border-t border-zinc-800">
                <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full bg-[#B600A8]/20 text-[#B600A8] border border-[#B600A8]/30 mb-2">
                  <Award size={13} />
                  <span>{language === 'vi' ? selectedMilestone.categoryVi : selectedMilestone.categoryEn}</span>
                </span>
                <h3 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-white mt-1">
                  {language === 'vi' ? selectedMilestone.titleVi : selectedMilestone.titleEn}
                </h3>
                <p className="text-sm text-zinc-300 mt-2 leading-relaxed">
                  {language === 'vi' ? selectedMilestone.descVi : selectedMilestone.descEn}
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};
