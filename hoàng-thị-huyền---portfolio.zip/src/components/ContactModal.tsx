import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Mail, Phone, MapPin, Linkedin, Facebook, Copy, Check, Send, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Language, Theme } from '../types';
import { PERSONAL_INFO, TRANSLATIONS } from '../data/translations';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  theme: Theme;
}

export const ContactModal: React.FC<ContactModalProps> = ({
  isOpen,
  onClose,
  language,
  theme,
}) => {
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const t = TRANSLATIONS[language];
  const isDark = theme === 'dark';

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#B600A8', '#7621B0', '#BE4C00', '#BBCCD7'],
      });
      setTimeout(() => {
        setFormData({ name: '', email: '', subject: '', message: '' });
        setIsSubmitted(false);
        onClose();
      }, 2500);
    }, 700);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className={`relative w-full max-w-2xl rounded-3xl p-6 sm:p-8 shadow-2xl border my-auto ${
              isDark
                ? 'bg-[#141416] border-zinc-800 text-[#D7E2EA]'
                : 'bg-white border-slate-200 text-slate-800 shadow-xl'
            }`}
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className={`absolute top-5 right-5 p-2 rounded-full transition-colors ${
                isDark ? 'hover:bg-zinc-800 text-zinc-400 hover:text-white' : 'hover:bg-slate-100 text-slate-500 hover:text-slate-900'
              }`}
              aria-label="Close modal"
            >
              <X size={20} />
            </button>

            {/* Header */}
            <div className="mb-6">
              <span className="text-xs uppercase tracking-widest text-[#B600A8] font-bold">
                {language === 'vi' ? 'Liên hệ & Kết nối' : 'Get in Touch'}
              </span>
              <h3 className="text-2xl sm:text-3xl font-black uppercase tracking-tight mt-1">
                {language === 'vi' ? 'Kết nối cùng Hoàng Thị Huyền' : 'Connect with Huyen Hoang'}
              </h3>
              <p className={`text-sm mt-1 ${isDark ? 'text-zinc-400' : 'text-slate-600'}`}>
                {t.contact.subtitle}
              </p>
            </div>

            {/* Quick Contact Chips / Action Items */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
              {/* Email */}
              <div
                className={`flex items-center justify-between p-3.5 rounded-2xl border transition-colors ${
                  isDark ? 'bg-zinc-900/60 border-zinc-800' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <a
                  href={`mailto:${PERSONAL_INFO.email}`}
                  className="flex items-center gap-3 truncate hover:text-[#B600A8] transition-colors"
                >
                  <Mail size={18} className="text-[#B600A8] shrink-0" />
                  <div className="truncate text-left">
                    <div className="text-[11px] uppercase tracking-wider opacity-60 font-semibold">Email</div>
                    <div className="text-xs sm:text-sm font-medium truncate">{PERSONAL_INFO.email}</div>
                  </div>
                </a>
                <button
                  onClick={() => copyToClipboard(PERSONAL_INFO.email, 'email')}
                  className={`p-2 rounded-xl transition-colors ${isDark ? 'hover:bg-zinc-800' : 'hover:bg-slate-200'}`}
                  title="Copy email"
                >
                  {copiedField === 'email' ? <Check size={16} className="text-green-500" /> : <Copy size={16} className="opacity-60" />}
                </button>
              </div>

              {/* Phone */}
              <div
                className={`flex items-center justify-between p-3.5 rounded-2xl border transition-colors ${
                  isDark ? 'bg-zinc-900/60 border-zinc-800' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <a
                  href={`tel:${PERSONAL_INFO.phone.replace(/[^0-9+]/g, '')}`}
                  className="flex items-center gap-3 truncate hover:text-[#B600A8] transition-colors"
                >
                  <Phone size={18} className="text-[#7621B0] shrink-0" />
                  <div className="truncate text-left">
                    <div className="text-[11px] uppercase tracking-wider opacity-60 font-semibold">
                      {language === 'vi' ? 'Điện thoại' : 'Phone'}
                    </div>
                    <div className="text-xs sm:text-sm font-medium truncate">{PERSONAL_INFO.phone}</div>
                  </div>
                </a>
                <button
                  onClick={() => copyToClipboard(PERSONAL_INFO.phone, 'phone')}
                  className={`p-2 rounded-xl transition-colors ${isDark ? 'hover:bg-zinc-800' : 'hover:bg-slate-200'}`}
                  title="Copy phone"
                >
                  {copiedField === 'phone' ? <Check size={16} className="text-green-500" /> : <Copy size={16} className="opacity-60" />}
                </button>
              </div>

              {/* LinkedIn */}
              <a
                href={PERSONAL_INFO.linkedIn}
                target="_blank"
                rel="noopener noreferrer"
                className={`flex items-center gap-3 p-3.5 rounded-2xl border transition-all hover:scale-[1.01] ${
                  isDark ? 'bg-zinc-900/60 border-zinc-800 hover:border-blue-500/50' : 'bg-slate-50 border-slate-200 hover:border-blue-400'
                }`}
              >
                <Linkedin size={18} className="text-blue-500 shrink-0" />
                <div className="truncate text-left">
                  <div className="text-[11px] uppercase tracking-wider opacity-60 font-semibold">LinkedIn</div>
                  <div className="text-xs sm:text-sm font-medium truncate">{PERSONAL_INFO.linkedInHandle}</div>
                </div>
              </a>

              {/* Location */}
              <div
                className={`flex items-center gap-3 p-3.5 rounded-2xl border ${
                  isDark ? 'bg-zinc-900/60 border-zinc-800' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <MapPin size={18} className="text-rose-500 shrink-0" />
                <div className="truncate text-left">
                  <div className="text-[11px] uppercase tracking-wider opacity-60 font-semibold">
                    {language === 'vi' ? 'Địa điểm' : 'Location'}
                  </div>
                  <div className="text-xs sm:text-sm font-medium truncate">{PERSONAL_INFO.location}</div>
                </div>
              </div>
            </div>

            {/* Direct Message Form */}
            {isSubmitted ? (
              <div className="py-8 text-center flex flex-col items-center justify-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-green-500/20 text-green-500 flex items-center justify-center">
                  <Check size={24} />
                </div>
                <h4 className="text-lg font-bold">{language === 'vi' ? 'Đã gửi thành công!' : 'Message Sent!'}</h4>
                <p className={`text-sm max-w-md ${isDark ? 'text-zinc-400' : 'text-slate-600'}`}>
                  {t.contact.form.successMsg}
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3.5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5 opacity-80">
                      {t.contact.form.nameLabel} <span className="text-[#B600A8]">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder={language === 'vi' ? 'Nguyễn Văn A' : 'Alex Johnson'}
                      className={`w-full px-4 py-2.5 rounded-xl border text-sm transition-colors outline-none focus:ring-2 focus:ring-[#B600A8] ${
                        isDark ? 'bg-zinc-900 border-zinc-800 text-white placeholder-zinc-500' : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5 opacity-80">
                      {t.contact.form.emailLabel} <span className="text-[#B600A8]">*</span>
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="your.email@company.com"
                      className={`w-full px-4 py-2.5 rounded-xl border text-sm transition-colors outline-none focus:ring-2 focus:ring-[#B600A8] ${
                        isDark ? 'bg-zinc-900 border-zinc-800 text-white placeholder-zinc-500' : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5 opacity-80">
                    {t.contact.form.subjectLabel}
                  </label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder={language === 'vi' ? 'Hợp tác dự án / Trao đổi công việc' : 'Project collaboration / Inquiries'}
                    className={`w-full px-4 py-2.5 rounded-xl border text-sm transition-colors outline-none focus:ring-2 focus:ring-[#B600A8] ${
                      isDark ? 'bg-zinc-900 border-zinc-800 text-white placeholder-zinc-500' : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5 opacity-80">
                    {t.contact.form.messageLabel} <span className="text-[#B600A8]">*</span>
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder={language === 'vi' ? 'Nội dung tin nhắn bạn muốn gửi...' : 'Your message details...'}
                    className={`w-full px-4 py-2.5 rounded-xl border text-sm transition-colors outline-none focus:ring-2 focus:ring-[#B600A8] resize-none ${
                      isDark ? 'bg-zinc-900 border-zinc-800 text-white placeholder-zinc-500' : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400'
                    }`}
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-xs opacity-60">
                    {copiedField && (
                      <span className="text-green-500 flex items-center gap-1 font-medium">
                        <Check size={13} /> {t.contact.form.copySuccess}
                      </span>
                    )}
                  </span>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="cursor-pointer inline-flex items-center gap-2 px-6 py-2.5 rounded-full font-semibold uppercase tracking-wider text-xs text-white bg-gradient-to-r from-[#B600A8] to-[#7621B0] hover:opacity-90 active:scale-95 transition-all disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      t.contact.form.sending
                    ) : (
                      <>
                        <Send size={13} />
                        <span>{t.contact.form.sendBtn}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
