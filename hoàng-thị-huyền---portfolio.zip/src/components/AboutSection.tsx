import React from 'react';
import { FadeIn } from './FadeIn';
import { AnimatedText } from './AnimatedText';
import { ContactButton } from './ContactButton';
import { DECORATIVE_ICONS, PDF_PHOTOS, PERSONAL_INFO, TOC_SECTIONS, TRANSLATIONS } from '../data/translations';
import { Language, Theme } from '../types';
import { GraduationCap, Award, BookOpen, Sparkles, CheckCircle2, ShieldCheck, HeartHandshake } from 'lucide-react';

interface AboutSectionProps {
  language: Language;
  theme: Theme;
  onOpenContact: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({
  language,
  theme,
  onOpenContact,
}) => {
  const t = TRANSLATIONS[language];
  const isDark = theme === 'dark';

  return (
    <section
      id="about"
      className={`relative w-full min-h-screen px-5 sm:px-8 md:px-10 py-20 flex flex-col items-center justify-center overflow-hidden transition-colors duration-300 ${
        isDark ? 'bg-[#0C0C0C]' : 'bg-[#F8FAFC]'
      }`}
    >
      {/* Four decorative 3D floating icons positioned in corners per spec */}
      {/* Top-left: Moon icon */}
      <div className="absolute top-[4%] left-[1%] sm:left-[2%] md:left-[4%] pointer-events-none z-10 w-[120px] sm:w-[160px] md:w-[210px]">
        <FadeIn delay={0.1} x={-80} y={0} duration={0.9}>
          <img
            src={DECORATIVE_ICONS.moon}
            alt="3D Moon element"
            loading="lazy"
            referrerPolicy="no-referrer"
            className="w-full h-auto drop-shadow-[0_15px_30px_rgba(0,0,0,0.4)] animate-pulse"
            style={{ animationDuration: '4s' }}
          />
        </FadeIn>
      </div>

      {/* Bottom-left: 3D object */}
      <div className="absolute bottom-[8%] left-[3%] sm:left-[6%] md:left-[10%] pointer-events-none z-10 w-[100px] sm:w-[140px] md:w-[180px]">
        <FadeIn delay={0.25} x={-80} y={0} duration={0.9}>
          <img
            src={DECORATIVE_ICONS.object3d}
            alt="3D Geometric Element"
            loading="lazy"
            referrerPolicy="no-referrer"
            className="w-full h-auto drop-shadow-[0_15px_30px_rgba(0,0,0,0.4)]"
          />
        </FadeIn>
      </div>

      {/* Top-right: Lego icon */}
      <div className="absolute top-[4%] right-[1%] sm:right-[2%] md:right-[4%] pointer-events-none z-10 w-[120px] sm:w-[160px] md:w-[210px]">
        <FadeIn delay={0.15} x={80} y={0} duration={0.9}>
          <img
            src={DECORATIVE_ICONS.lego}
            alt="3D Lego element"
            loading="lazy"
            referrerPolicy="no-referrer"
            className="w-full h-auto drop-shadow-[0_15px_30px_rgba(0,0,0,0.4)]"
          />
        </FadeIn>
      </div>

      {/* Bottom-right: 3D group */}
      <div className="absolute bottom-[8%] right-[3%] sm:right-[6%] md:right-[10%] pointer-events-none z-10 w-[130px] sm:w-[170px] md:w-[220px]">
        <FadeIn delay={0.3} x={80} y={0} duration={0.9}>
          <img
            src={DECORATIVE_ICONS.group3d}
            alt="3D Composition Element"
            loading="lazy"
            referrerPolicy="no-referrer"
            className="w-full h-auto drop-shadow-[0_15px_30px_rgba(0,0,0,0.4)]"
          />
        </FadeIn>
      </div>

      {/* Central Content Column */}
      <div className="relative z-20 w-full max-w-5xl mx-auto flex flex-col items-center">
        {/* Table of Contents bar from Page 1 of PDF */}
        <FadeIn delay={0} y={-10}>
          <div className="flex flex-wrap items-center justify-center gap-2 mb-8 px-4 py-2 rounded-full border border-[#D7E2EA]/20 bg-zinc-900/60 backdrop-blur-md">
            {TOC_SECTIONS.map((sec) => (
              <a
                key={sec.id}
                href={sec.href}
                className="text-[11px] sm:text-xs font-semibold uppercase tracking-wider px-2.5 py-1 rounded-full text-[#D7E2EA] hover:text-[#B600A8] transition-colors"
              >
                <span className="text-[#B600A8] mr-1 font-bold">{sec.id}</span>
                <span>{language === 'vi' ? sec.labelVi : sec.labelEn}</span>
              </a>
            ))}
          </div>
        </FadeIn>

        {/* Main Heading: "About me" */}
        <FadeIn delay={0.05} y={40}>
          <div className="text-center">
            <span className="text-xs uppercase tracking-widest text-[#B600A8] font-bold">
              {t.about.badge}
            </span>
            <h2
              className={`font-black uppercase leading-none tracking-tight text-center mt-1 ${
                isDark ? 'hero-heading' : 'hero-heading-light'
              }`}
              style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
            >
              {t.about.heading}
            </h2>
            <p className="text-base sm:text-lg font-bold text-[#BBCCD7] mt-2">
              {PERSONAL_INFO.fullName}
            </p>
          </div>
        </FadeIn>

        {/* Gap between heading and text: gap-10 sm:gap-14 md:gap-16 */}
        <div className="h-10 sm:h-12 md:h-14" />

        {/* Character-by-character animated paragraph from PDF */}
        <div className="px-4">
          <AnimatedText
            text={t.about.paragraph}
            theme={theme}
          />
        </div>

        {/* 3 Core Strengths from Page 2 of PDF */}
        <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-4 mt-12 px-4">
          {t.about.strengths.map((st, idx) => {
            const icons = [
              <CheckCircle2 key="0" size={20} className="text-[#B600A8] shrink-0" />,
              <HeartHandshake key="1" size={20} className="text-[#7621B0] shrink-0" />,
              <ShieldCheck key="2" size={20} className="text-[#BE4C00] shrink-0" />,
            ];

            return (
              <FadeIn key={idx} delay={0.2 + idx * 0.1} y={20}>
                <div
                  className={`p-5 rounded-2xl border h-full transition-all duration-300 hover:border-[#B600A8] ${
                    isDark ? 'bg-zinc-900/60 border-zinc-800 text-[#D7E2EA]' : 'bg-white border-slate-200 text-slate-800 shadow-sm'
                  }`}
                >
                  <div className="flex items-center gap-2.5 mb-2 font-bold text-sm">
                    {icons[idx % icons.length]}
                    <h4>{st.title}</h4>
                  </div>
                  <p className="text-xs opacity-80 leading-relaxed">
                    {st.desc}
                  </p>
                </div>
              </FadeIn>
            );
          })}
        </div>

        {/* Gap between text block and button */}
        <div className="h-12 sm:h-16 md:h-20" />

        {/* Contact Button */}
        <FadeIn delay={0.2} y={20}>
          <ContactButton
            label={t.contact.buttonText}
            onClick={onOpenContact}
          />
        </FadeIn>

        {/* 02 EDUCATION SECTION (from Page 2 of PDF) */}
        <div id="education" className="w-full mt-24 pt-10 border-t border-zinc-800/60">
          <FadeIn delay={0.1} y={30}>
            <div className="text-center mb-10">
              <span className="text-xs uppercase tracking-widest text-[#B600A8] font-bold">
                {t.education.badge}
              </span>
              <h3 className="text-3xl sm:text-4xl font-black uppercase tracking-tight mt-1">
                {t.education.title}
              </h3>
              <p className="text-xs sm:text-sm text-zinc-400 mt-1">
                {t.education.subtitle}
              </p>
            </div>
          </FadeIn>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
            {t.education.items.map((item, idx) => (
              <FadeIn key={idx} delay={0.15 + idx * 0.1} y={30}>
                <div
                  className={`h-full p-6 sm:p-8 rounded-3xl border transition-all duration-300 hover:border-[#B600A8]/60 ${
                    isDark
                      ? 'bg-zinc-900/40 border-zinc-800/80 text-[#D7E2EA]'
                      : 'bg-white border-slate-200 text-slate-800 shadow-sm'
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-semibold px-3 py-1 rounded-full bg-[#B600A8]/15 text-[#B600A8]">
                      {item.period}
                    </span>
                    <GraduationCap size={22} className="text-[#BBCCD7]" />
                  </div>
                  <h4 className="text-xl sm:text-2xl font-bold tracking-tight">
                    {item.school}
                  </h4>
                  {item.degree ? (
                    <p className="text-sm font-medium text-[#B600A8] mt-1 mb-4">
                      {item.degree}
                    </p>
                  ) : (
                    <div className="mb-4" />
                  )}
                  <ul className="space-y-2">
                    {item.highlights.map((h, hIdx) => (
                      <li key={hIdx} className="text-sm opacity-85 flex items-start gap-2.5">
                        <span className="text-[#B600A8] mt-1 font-bold">▪</span>
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
