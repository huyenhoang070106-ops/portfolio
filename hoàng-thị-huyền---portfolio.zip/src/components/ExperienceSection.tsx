import React, { useState } from 'react';
import { FadeIn } from './FadeIn';
import { TRANSLATIONS } from '../data/translations';
import { Language, Theme } from '../types';
import { Briefcase, Calendar, CheckCircle2, ChevronRight, Eye, X } from 'lucide-react';

interface ExperienceSectionProps {
  language: Language;
  theme: Theme;
}

export const ExperienceSection: React.FC<ExperienceSectionProps> = ({
  language,
  theme,
}) => {
  const [selectedPhoto, setSelectedPhoto] = useState<{ src: string; title: string } | null>(null);
  const t = TRANSLATIONS[language];
  const isDark = theme === 'dark';

  return (
    <section
      id="experience"
      className={`w-full px-5 sm:px-8 md:px-12 py-24 relative z-10 transition-colors duration-300 ${
        isDark ? 'bg-[#0E0E10] text-[#D7E2EA]' : 'bg-slate-100 text-slate-800'
      }`}
    >
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <FadeIn delay={0} y={40}>
          <div className="text-center mb-16 sm:mb-20">
            <span className="text-xs font-bold uppercase tracking-widest text-[#B600A8]">
              {t.experience.badge}
            </span>
            <h2
              className={`font-black uppercase tracking-tight leading-none mt-2 ${
                isDark ? 'hero-heading' : 'hero-heading-light'
              }`}
              style={{ fontSize: 'clamp(2.8rem, 10vw, 130px)' }}
            >
              {t.experience.heading}
            </h2>
            <p className="mt-3 text-xs sm:text-sm font-semibold uppercase tracking-widest text-[#BBCCD7]">
              {t.experience.subtitle}
            </p>
          </div>
        </FadeIn>

        {/* Experience Cards Stack */}
        <div className="space-y-8">
          {t.experience.items.map((item, idx) => (
            <FadeIn key={idx} delay={idx * 0.1} y={30}>
              <div
                className={`rounded-3xl border p-6 sm:p-8 transition-all duration-300 hover:border-[#B600A8]/80 ${
                  isDark
                    ? 'bg-[#141416]/80 border-zinc-800 shadow-xl'
                    : 'bg-white border-slate-200 shadow-md'
                }`}
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
                  {/* Photo Column (4 cols on lg) */}
                  <div className="lg:col-span-4 w-full flex flex-col gap-2.5">
                    <div
                      onClick={() => setSelectedPhoto({ src: item.photo, title: item.organization })}
                      className="group relative cursor-pointer overflow-hidden rounded-2xl border border-white/10 aspect-[4/3] bg-zinc-900 shadow-md"
                    >
                      <img
                        src={item.photo}
                        alt={item.organization}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/70 text-white text-xs font-medium backdrop-blur-sm">
                          <Eye size={14} />
                          <span>{language === 'vi' ? 'Xem ảnh' : 'View photo'}</span>
                        </span>
                      </div>
                    </div>

                    {/* Extra gallery thumbnails if available */}
                    {item.gallery && item.gallery.length > 0 && (
                      <div className="flex items-center gap-2 overflow-x-auto pb-1">
                        {item.gallery.map((gPhoto, gIdx) => (
                          <div
                            key={gIdx}
                            onClick={() => setSelectedPhoto({ src: gPhoto, title: `${item.organization} - Visual ${gIdx + 2}` })}
                            className="w-16 h-12 rounded-xl overflow-hidden border border-white/15 cursor-pointer shrink-0 hover:border-[#B600A8] transition-all opacity-80 hover:opacity-100"
                          >
                            <img
                              src={gPhoto}
                              alt={`Thumbnail ${gIdx + 1}`}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Content Column (8 cols on lg) */}
                  <div className="lg:col-span-8 flex flex-col justify-between h-full">
                    <div>
                      {/* Top Badges */}
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                        <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full bg-gradient-to-r from-[#B600A8]/20 to-[#7621B0]/20 text-[#B600A8] border border-[#B600A8]/30">
                          <Briefcase size={13} />
                          <span>{item.role}</span>
                        </span>

                        <span className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1 rounded-full bg-zinc-800/40 text-zinc-400">
                          <Calendar size={13} />
                          <span>{item.period}</span>
                        </span>
                      </div>

                      {/* Organization Title */}
                      <h3 className="text-xl sm:text-2xl font-black uppercase tracking-tight mb-4">
                        {item.organization}
                      </h3>

                      {/* Bullet descriptions */}
                      <ul className="space-y-2.5 mb-6 text-sm opacity-85 leading-relaxed">
                        {item.description.map((bullet, bIdx) => (
                          <li key={bIdx} className="flex items-start gap-2.5">
                            <span className="text-[#B600A8] mt-1 shrink-0 font-bold">▪</span>
                            <span>{bullet}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Highlights tags */}
                    <div className="flex flex-wrap items-center gap-2 pt-4 border-t border-zinc-800/40">
                      {item.highlights.map((tag, tIdx) => (
                        <span
                          key={tIdx}
                          className="text-xs font-medium px-3 py-1 rounded-lg bg-zinc-800/60 text-[#D7E2EA] border border-zinc-700/50"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {selectedPhoto && (
        <div
          onClick={() => setSelectedPhoto(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-4xl max-h-[90vh] rounded-3xl overflow-hidden shadow-2xl border border-white/20 bg-zinc-950 cursor-default"
          >
            <button
              onClick={() => setSelectedPhoto(null)}
              className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-black/60 text-white hover:bg-black/90 transition-colors"
              aria-label="Close"
            >
              <X size={20} />
            </button>
            <img
              src={selectedPhoto.src}
              alt={selectedPhoto.title}
              className="max-h-[80vh] w-auto object-contain mx-auto"
            />
            <div className="p-4 bg-zinc-900 text-white text-sm font-medium text-center">
              {selectedPhoto.title}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
