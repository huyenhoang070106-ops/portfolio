import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Play, Pause, Music } from 'lucide-react';
import { Language, Theme } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface AudioPlayerProps {
  language: Language;
  theme: Theme;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({ language, theme }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.5);
  const [isExpanded, setIsExpanded] = useState(false);
  
  // Web Audio API ambient lofi chord synth
  const audioCtxRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const intervalRef = useRef<any>(null);

  const t = TRANSLATIONS[language];

  // Notes for a lush, relaxing Lo-Fi / Neosoul chord progression:
  // Fmaj9 -> Em7 -> Dm9 -> Cmaj7
  const chords = [
    [174.61, 220.00, 261.63, 329.63, 392.00], // F3, A3, C4, E4, G4 (Fmaj9)
    [164.81, 196.00, 246.94, 293.66, 349.23], // E3, G3, B3, D4, F4 (Em7)
    [146.83, 174.61, 220.00, 261.63, 329.63], // D3, F3, A3, C4, E4 (Dm9)
    [130.81, 164.81, 196.00, 246.94, 293.66], // C3, E3, G3, B3, D4 (Cmaj9)
  ];

  const playChord = (chordIdx: number) => {
    if (!audioCtxRef.current || !gainNodeRef.current) return;
    const ctx = audioCtxRef.current;
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
    const chord = chords[chordIdx % chords.length];
    const now = ctx.currentTime;

    chord.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const noteGain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      // Soft triangle/sine blend for warm lofi sound
      osc.type = i === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.08);

      // Lowpass filter for dreamy vintage warmth
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(650 + Math.sin(now) * 150, now);
      filter.Q.setValueAtTime(1.5, now);

      // Smooth attack and long decay
      noteGain.gain.setValueAtTime(0, now + i * 0.08);
      noteGain.gain.linearRampToValueAtTime(0.045, now + i * 0.08 + 0.4);
      noteGain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.08 + 4.2);

      osc.connect(filter);
      filter.connect(noteGain);
      noteGain.connect(gainNodeRef.current!);

      osc.start(now + i * 0.08);
      osc.stop(now + i * 0.08 + 4.5);
    });
  };

  const startAudio = () => {
    try {
      if (!audioCtxRef.current) {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        audioCtxRef.current = new AudioContextClass();
        gainNodeRef.current = audioCtxRef.current.createGain();
        gainNodeRef.current.gain.setValueAtTime(isMuted ? 0 : volume * 0.7, audioCtxRef.current.currentTime);
        gainNodeRef.current.connect(audioCtxRef.current.destination);
      }

      if (audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }

      let step = 0;
      playChord(step);
      step++;

      if (intervalRef.current) clearInterval(intervalRef.current);
      intervalRef.current = setInterval(() => {
        playChord(step);
        step = (step + 1) % chords.length;
      }, 3400);

      setIsPlaying(true);
    } catch (e) {
      console.warn("Audio initiation error:", e);
    }
  };

  const stopAudio = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsPlaying(false);
  };

  const togglePlay = () => {
    if (isPlaying) {
      stopAudio();
    } else {
      startAudio();
    }
  };

  const toggleMute = () => {
    if (!gainNodeRef.current || !audioCtxRef.current) return;
    const now = audioCtxRef.current.currentTime;
    if (isMuted) {
      gainNodeRef.current.gain.setValueAtTime(volume * 0.7, now);
      setIsMuted(false);
    } else {
      gainNodeRef.current.gain.setValueAtTime(0, now);
      setIsMuted(true);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVol = parseFloat(e.target.value);
    setVolume(newVol);
    if (gainNodeRef.current && audioCtxRef.current) {
      const now = audioCtxRef.current.currentTime;
      if (!isMuted) {
        gainNodeRef.current.gain.setValueAtTime(newVol * 0.7, now);
      }
    }
  };

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (audioCtxRef.current) {
        audioCtxRef.current.close().catch(() => {});
      }
    };
  }, []);

  const [isHovered, setIsHovered] = useState(false);
  const isDark = theme === 'dark';
  const isWidgetOpen = isHovered || isExpanded;

  return (
    <div 
      className="fixed bottom-6 right-6 z-50 flex items-center select-none"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div 
        className={`flex items-center rounded-full backdrop-blur-md transition-all duration-300 ease-out shadow-2xl border ${
          isDark 
            ? 'bg-[#141416]/90 border-[#27272a] text-[#D7E2EA]' 
            : 'bg-white/95 border-slate-200 text-slate-800 shadow-slate-300/60'
        } ${isWidgetOpen ? 'px-4 py-2.5 gap-3' : 'p-2 gap-2'}`}
      >
        {/* Play/Pause Button */}
        <button
          onClick={togglePlay}
          className="relative shrink-0 flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-tr from-[#B600A8] to-[#7621B0] text-white hover:scale-105 active:scale-95 transition-transform cursor-pointer"
          title={isPlaying ? t.audio.paused : t.audio.playing}
          aria-label={t.audio.toggle}
        >
          {isPlaying ? <Pause size={13} className="fill-white" /> : <Play size={13} className="fill-white ml-0.5" />}
        </button>

        {/* Audio Visualizer Waves */}
        <div 
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center gap-1 cursor-pointer"
          title="Click to toggle details"
        >
          <div className="flex items-end gap-[3px] h-4 w-6 shrink-0">
            <span className={`w-1 bg-[#B600A8] rounded-full transition-all duration-150 ${isPlaying ? 'audio-bar-1' : 'h-1.5'}`} />
            <span className={`w-1 bg-[#7621B0] rounded-full transition-all duration-150 ${isPlaying ? 'audio-bar-2' : 'h-3'}`} />
            <span className={`w-1 bg-[#BE4C00] rounded-full transition-all duration-150 ${isPlaying ? 'audio-bar-3' : 'h-2'}`} />
            <span className={`w-1 bg-[#BBCCD7] rounded-full transition-all duration-150 ${isPlaying ? 'audio-bar-4' : 'h-3.5'}`} />
          </div>

          {/* Details displayed ONLY on hover or expansion */}
          {isWidgetOpen && (
            <div className="flex flex-col ml-1 animate-fadeIn whitespace-nowrap">
              <span className="text-xs font-semibold tracking-wide">
                {isPlaying ? t.audio.trackName : (language === 'vi' ? 'Nhạc nền (Bấm Play)' : 'Background Music')}
              </span>
              <span className={`text-[10px] tracking-wider uppercase ${isDark ? 'text-zinc-400' : 'text-slate-400'}`}>
                {isPlaying ? (language === 'vi' ? 'Đang phát • Lofi Chords' : 'Now Playing • Lofi') : (language === 'vi' ? 'Nhấp để bật âm thanh' : 'Click to play')}
              </span>
            </div>
          )}
        </div>

        {/* Volume & Mute Controls (Visible ONLY on hover / expanded) */}
        {isWidgetOpen && (
          <div className={`items-center gap-2 pl-2 border-l animate-fadeIn flex ${isDark ? 'border-zinc-800' : 'border-slate-200'}`}>
            <button
              onClick={toggleMute}
              className={`p-1 rounded-full transition-colors cursor-pointer ${isDark ? 'hover:bg-zinc-800 text-zinc-300' : 'hover:bg-slate-100 text-slate-600'}`}
              aria-label="Mute/Unmute"
            >
              {isMuted || volume === 0 ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
            
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              className="w-16 h-1 accent-[#B600A8] cursor-pointer rounded-lg bg-zinc-700"
              aria-label="Volume slider"
            />
          </div>
        )}
      </div>
    </div>
  );
};
