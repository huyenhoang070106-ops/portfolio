import React from 'react';
import { FadeIn } from './FadeIn';
import { PERSONAL_INFO, TRANSLATIONS } from '../data/translations';
import { Language, Theme } from '../types';
import { Database, BarChart3, Languages, Briefcase, Users, MessageSquare, Lightbulb, CheckCircle2 } from 'lucide-react';

interface SkillsSectionProps {
  language: Language;
  theme: Theme;
}

export const SkillsSection: React.FC<SkillsSectionProps> = ({
  language,
  theme,
}) => {
  const t = TRANSLATIONS[language];
  const isDark = theme === 'dark';

  return (
    <section
      id="skills"
      className={`w-full px-5 sm:px-8 md:px-10 py-20 relative z-10 transition-colors duration-300 ${
        isDark ? 'bg-[#0C0C0C] text-[#D7E2EA]' : 'bg-[#F8FAFC] text-slate-800'
      }`}
    >
      <div className="max-w-6xl mx-auto">
        <FadeIn delay={0} y={40}>
          <div className="text-center mb-16">
            <span className="text-xs uppercase tracking-widest text-[#B600A8] font-bold">
              {t.skills.badge}
            </span>
            <h2
              className={`font-black uppercase tracking-tight leading-none mt-1 ${
                isDark ? 'hero-heading' : 'hero-heading-light'
              }`}
              style={{ fontSize: 'clamp(2.8rem, 10vw, 130px)' }}
            >
              {t.skills.heading}
            </h2>
            <p className="mt-3 text-xs sm:text-sm font-semibold uppercase tracking-widest text-[#B600A8]">
              {t.skills.subtitle}
            </p>
          </div>
        </FadeIn>

        {/* Bento Grid: Hard Skills (Left 60%) + Soft Skills (Right 40%) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* HARD SKILLS */}
          <div className="lg:col-span-7 space-y-6">
            <FadeIn delay={0.1} y={20}>
              <div className="flex items-center gap-2 mb-2">
                <Database size={18} className="text-[#B600A8]" />
                <h3 className="text-sm font-bold uppercase tracking-wider text-[#B600A8]">
                  {t.skills.hardTitle}
                </h3>
              </div>
            </FadeIn>

            {/* Python & Data Processing Card */}
            <FadeIn delay={0.15} y={25}>
              <div
                className={`p-6 sm:p-7 rounded-3xl border transition-all duration-300 hover:border-[#B600A8] ${
                  isDark ? 'bg-zinc-900/40 border-zinc-800' : 'bg-white border-slate-200 shadow-sm'
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold font-mono">
                      PY
                    </div>
                    <div>
                      <h4 className="text-lg font-bold">Python</h4>
                      <p className="text-xs opacity-60">Pandas · NumPy · Data Wrangling</p>
                    </div>
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-400">
                    {language === 'vi' ? 'Cơ bản' : 'Fundamentals'}
                  </span>
                </div>
                <p className="text-sm opacity-80 leading-relaxed">
                  {language === 'vi'
                    ? 'Xử lý, làm sạch và chuẩn hoá dữ liệu có cấu trúc. Biến đổi dữ liệu đa chiều phục vụ mô hình kinh tế và báo cáo quyết định.'
                    : 'Data cleansing, pipeline transformation, and exploratory data analysis using Pandas and NumPy for quantitative insights.'}
                </p>
              </div>
            </FadeIn>

            {/* Power BI & Data Modeling Card */}
            <FadeIn delay={0.2} y={25}>
              <div
                className={`p-6 sm:p-7 rounded-3xl border transition-all duration-300 hover:border-[#7621B0] ${
                  isDark ? 'bg-zinc-900/40 border-zinc-800' : 'bg-white border-slate-200 shadow-sm'
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-yellow-500/10 text-yellow-500 flex items-center justify-center">
                      <BarChart3 size={20} />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold">Power BI</h4>
                      <p className="text-xs opacity-60">Star Schema · DAX Measures · Interactive Reports</p>
                    </div>
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-yellow-500/15 text-yellow-500">
                    {language === 'vi' ? 'Cơ bản' : 'Fundamentals'}
                  </span>
                </div>
                <p className="text-sm opacity-80 leading-relaxed">
                  {language === 'vi'
                    ? 'Khởi tạo mô hình quan hệ Star Schema chuẩn hoá, viết hàm DAX tùy biến và xây dựng Dashboard trực quan sinh động phản ánh KPI.'
                    : 'Architecting Star Schema relational models, authoring custom DAX metric calculations, and designing intuitive executive dashboards.'}
                </p>
              </div>
            </FadeIn>

            {/* English & Productivity Tools */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FadeIn delay={0.25} y={25}>
                <div
                  className={`p-5 rounded-3xl border h-full transition-all duration-300 ${
                    isDark ? 'bg-zinc-900/40 border-zinc-800' : 'bg-white border-slate-200 shadow-sm'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Languages size={18} className="text-blue-400" />
                    <h5 className="font-bold text-sm">English Proficiency</h5>
                  </div>
                  <p className="text-xs font-semibold text-blue-400 mb-2">
                    {language === 'vi' ? 'Giải Nhì HSG Cấp Tỉnh' : 'Provincial 2nd Prize'}
                  </p>
                  <p className="text-xs opacity-70 leading-relaxed">
                    {language === 'vi'
                      ? 'Năng lực giao tiếp, viết báo cáo học thuật và đàm phán trực tiếp với đối tác quốc tế.'
                      : 'Fluency in negotiation, academic reporting, and communicating with international organizations.'}
                  </p>
                </div>
              </FadeIn>

              <FadeIn delay={0.3} y={25}>
                <div
                  className={`p-5 rounded-3xl border h-full transition-all duration-300 ${
                    isDark ? 'bg-zinc-900/40 border-zinc-800' : 'bg-white border-slate-200 shadow-sm'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Briefcase size={18} className="text-emerald-400" />
                    <h5 className="font-bold text-sm">Office & Digital Tools</h5>
                  </div>
                  <p className="text-xs font-semibold text-emerald-400 mb-2">
                    Notion · Excel · Canva
                  </p>
                  <p className="text-xs opacity-70 leading-relaxed">
                    {language === 'vi'
                      ? 'Soạn thảo giáo trình, thiết kế ấn phẩm và quản trị dự án số trên Google Workspace & Notion.'
                      : 'Structured curriculum design, media graphics, and database operations in Notion and Workspace.'}
                  </p>
                </div>
              </FadeIn>
            </div>
          </div>

          {/* SOFT SKILLS */}
          <div className="lg:col-span-5 space-y-4">
            <FadeIn delay={0.1} y={20}>
              <div className="flex items-center gap-2 mb-2">
                <Users size={18} className="text-[#7621B0]" />
                <h3 className="text-sm font-bold uppercase tracking-wider text-[#7621B0]">
                  {t.skills.softTitle}
                </h3>
              </div>
            </FadeIn>

            {t.skills.soft.map((item, idx) => {
              const icons = [
                <Briefcase key="0" size={20} className="text-[#B600A8]" />,
                <Users key="1" size={20} className="text-[#7621B0]" />,
                <MessageSquare key="2" size={20} className="text-[#BE4C00]" />,
                <Lightbulb key="3" size={20} className="text-amber-400" />,
              ];

              return (
                <FadeIn key={idx} delay={0.15 + idx * 0.08} y={20}>
                  <div
                    className={`p-5 rounded-2xl border transition-all duration-300 group hover:translate-x-1 ${
                      isDark
                        ? 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'
                        : 'bg-white border-slate-200 shadow-sm hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start gap-3.5">
                      <div className="p-2.5 rounded-xl bg-zinc-800/50 shrink-0 mt-0.5">
                        {icons[idx % icons.length]}
                      </div>
                      <div>
                        <h4 className="font-bold text-base group-hover:text-[#B600A8] transition-colors">
                          {item.name}
                        </h4>
                        <p className="text-xs opacity-70 mt-1 leading-relaxed">
                          {item.desc}
                        </p>
                      </div>
                    </div>
                  </div>
                </FadeIn>
              );
            })}

            {/* YOLO Slogan Card */}
            <FadeIn delay={0.5} y={20}>
              <div
                className="p-6 sm:p-7 rounded-3xl relative overflow-hidden border border-white/10"
                style={{
                  background: 'linear-gradient(135deg, #18011F 0%, #3B0764 50%, #1E1B4B 100%)',
                }}
              >
                <div className="relative z-10 text-white">
                  <span className="text-[11px] uppercase tracking-widest text-[#BBCCD7] font-bold">
                    {language === 'vi' ? 'Slogan cá nhân' : 'Personal Slogan'}
                  </span>
                  <div className="text-4xl sm:text-5xl font-black tracking-tight text-white mt-1 mb-2 font-['Lora',serif]">
                    YOLO<span className="text-[#B600A8]">.</span>
                  </div>
                  <p className="text-xs uppercase tracking-wider text-zinc-300 font-medium">
                    You Only Live Once
                  </p>
                  <p className="text-xs text-right mt-3 text-[#BBCCD7] font-semibold">
                    — {PERSONAL_INFO.fullName}
                  </p>
                </div>
              </div>
            </FadeIn>
          </div>
        </div>
      </div>
    </section>
  );
};
