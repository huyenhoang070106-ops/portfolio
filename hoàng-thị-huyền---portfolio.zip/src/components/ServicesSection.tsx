import React from 'react';
import { FadeIn } from './FadeIn';
import { TRANSLATIONS } from '../data/translations';
import { Language, Theme } from '../types';

interface ServicesSectionProps {
  language: Language;
  theme: Theme;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  language,
}) => {
  const t = TRANSLATIONS[language];

  return (
    <section
      id="services"
      className="w-full bg-[#FFFFFF] text-[#0C0C0C] rounded-t-[40px] sm:rounded-t-[50px] md:rounded-t-[60px] px-5 sm:px-8 md:px-10 py-20 sm:py-24 md:py-32 relative z-10 select-none"
    >
      <div className="max-w-5xl mx-auto">
        {/* Section Heading */}
        <FadeIn delay={0} y={40}>
          <div className="text-center mb-16 sm:mb-20 md:mb-28">
            <h2
              className="font-black uppercase tracking-tight text-[#0C0C0C] leading-none"
              style={{ fontSize: 'clamp(3rem, 12vw, 160px)' }}
            >
              {t.services.heading}
            </h2>
            <p className="mt-4 text-xs sm:text-sm font-semibold uppercase tracking-widest text-[#7621B0]">
              {t.services.subtitle}
            </p>
          </div>
        </FadeIn>

        {/* 5 Service Items in vertical list */}
        <div className="divide-y divide-[rgba(12,12,12,0.15)] border-t border-b border-[rgba(12,12,12,0.15)]">
          {t.services.items.map((item, idx) => (
            <FadeIn key={idx} delay={idx * 0.1} y={30}>
              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between py-8 sm:py-10 md:py-12 gap-4 sm:gap-8 group transition-colors">
                {/* Huge Number */}
                <div
                  className="font-black text-[#0C0C0C] leading-none shrink-0 sm:w-[160px] md:w-[220px] transition-transform duration-300 group-hover:translate-x-2"
                  style={{ fontSize: 'clamp(3rem, 10vw, 140px)' }}
                >
                  {item.number}
                </div>

                {/* Name + Description stacked vertically on right */}
                <div className="flex-1 flex flex-col justify-center">
                  <h3
                    className="font-medium uppercase tracking-tight text-[#0C0C0C] mb-3 group-hover:text-[#7621B0] transition-colors"
                    style={{ fontSize: 'clamp(1rem, 2.2vw, 2.1rem)' }}
                  >
                    {item.title}
                  </h3>
                  <p
                    className="font-light leading-relaxed max-w-2xl text-[#0C0C0C] opacity-60"
                    style={{ fontSize: 'clamp(0.85rem, 1.6vw, 1.25rem)' }}
                  >
                    {item.description}
                  </p>

                  {/* Tool chips */}
                  {item.tools && (
                    <div className="flex flex-wrap items-center gap-2 mt-4">
                      {item.tools.map((tool, tIdx) => (
                        <span
                          key={tIdx}
                          className="text-xs font-semibold px-2.5 py-1 rounded-md bg-neutral-100 text-neutral-700 tracking-wide"
                        >
                          {tool}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};
