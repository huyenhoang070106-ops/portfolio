export type Language = 'vi' | 'en';
export type Theme = 'dark' | 'light';

export interface EducationItem {
  school: string;
  period: string;
  degree: string;
  highlights: string[];
}

export interface ExperienceItem {
  role: string;
  organization: string;
  period?: string;
  photo: string;
  gallery?: string[];
  description: string[];
  highlights: string[];
}

export interface ProjectCardData {
  id: string;
  number: string;
  category: string;
  title: string;
  period: string;
  description: string;
  role: string;
  metrics: string[];
  tags: string[];
  col1Image1: string;
  col1Image2: string;
  col2Image: string;
  liveLink?: string;
}

export interface ServiceItem {
  number: string;
  title: string;
  description: string;
  tools?: string[];
}

export interface SkillCategory {
  title: string;
  skills: {
    name: string;
    level: string;
    details: string;
    icon?: string;
  }[];
}
