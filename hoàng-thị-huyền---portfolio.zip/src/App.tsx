/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { HeroSection } from './components/HeroSection';
import { MarqueeSection } from './components/MarqueeSection';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { SkillsSection } from './components/SkillsSection';
import { ExperienceSection } from './components/ExperienceSection';
import { ProjectsSection } from './components/ProjectsSection';
import { Footer } from './components/Footer';
import { AudioPlayer } from './components/AudioPlayer';
import { ContactModal } from './components/ContactModal';
import { Language, Theme } from './types';

export default function App() {
  const [language, setLanguage] = useState<Language>('vi');
  const [theme, setTheme] = useState<Theme>('dark');
  const [isContactOpen, setIsContactOpen] = useState(false);

  // Synchronize document theme class
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'light') {
      root.classList.add('light');
      root.style.backgroundColor = '#F8FAFC';
    } else {
      root.classList.remove('light');
      root.style.backgroundColor = '#0C0C0C';
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const isDark = theme === 'dark';

  return (
    <div
      style={{ overflowX: 'clip' }}
      className={`min-h-screen w-full transition-colors duration-300 font-['Lora',serif] ${
        isDark ? 'bg-[#0C0C0C] text-[#D7E2EA]' : 'bg-[#F8FAFC] text-slate-800'
      }`}
    >
      {/* 1. Hero Section */}
      <HeroSection
        language={language}
        onLanguageChange={setLanguage}
        theme={theme}
        onThemeToggle={toggleTheme}
        onOpenContact={() => setIsContactOpen(true)}
      />

      {/* 2. Marquee Section with authentic achievements and click effect */}
      <MarqueeSection theme={theme} language={language} />

      {/* 3. About Section with 4 3D icons & character-by-character scroll animation */}
      <AboutSection
        language={language}
        theme={theme}
        onOpenContact={() => setIsContactOpen(true)}
      />

      {/* 4. Services Section (White background contrast & 5 core competencies) */}
      <ServicesSection
        language={language}
        theme={theme}
      />

      {/* 5. Skills Section (Bento Grid: Hard Skills & Soft Skills) */}
      <SkillsSection
        language={language}
        theme={theme}
      />

      {/* 04. Experience Section (All 5 Activities from PDF with authentic photos) */}
      <ExperienceSection
        language={language}
        theme={theme}
      />

      {/* 05. Projects Section (Sticky Stacking Cards with scale & image previews) */}
      <ProjectsSection
        language={language}
        theme={theme}
      />

      {/* 7. Footer */}
      <Footer
        language={language}
        theme={theme}
        onOpenContact={() => setIsContactOpen(true)}
      />

      {/* Interactive Background Music Player */}
      <AudioPlayer
        language={language}
        theme={theme}
      />

      {/* Interactive Contact & Inquiry Modal */}
      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
        language={language}
        theme={theme}
      />
    </div>
  );
}
